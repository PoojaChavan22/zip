package com.capgemini.core.busbooking.service;

import java.util.List;

import com.capgemini.core.busbooking.doa.BusBookingDAOImpl;
import com.capgemini.core.busbooking.doa.IBusBookingDAO;
import com.capgemini.core.busbooking.dto.BookingDetails;
import com.capgemini.core.busbooking.dto.BusSchedule;
import com.capgemini.core.busbooking.exception.BusBookingException;

public class BusBookingServiceImpl implements IBusBookingService {

	private IBusBookingDAO busBookingDAO;
	
	public BusBookingServiceImpl() 
	{
		//loose coupling
		busBookingDAO = new BusBookingDAOImpl();
	}

	@Override
	public List<BusSchedule> getBusSchedule() throws BusBookingException {
		
		return busBookingDAO.getBusSchedule();
	}

	@Override
	public int bookABus(BookingDetails bookingDetails) throws BusBookingException {
		
		return busBookingDAO.bookABus( bookingDetails );
	}
}
