package com.capgemini.core.busbooking.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.core.busbooking.dto.BookingDetails;
import com.capgemini.core.busbooking.dto.BusSchedule;
import com.capgemini.core.busbooking.exception.BusBookingException;
import com.capgemini.core.busbooking.service.BusBookingServiceImpl;
import com.capgemini.core.busbooking.service.IBusBookingService;

public class TestBusBookingDAOImpl {

	private static IBusBookingService bookingService;
	
	@BeforeClass
	public static void init()
	{
		bookingService = new BusBookingServiceImpl();
	}
	
	@AfterClass
	public static void cleanup()
	{
		bookingService = null;
	}
	
	@Test
	public void testGetBusSchedule() throws BusBookingException 
	{
		List<BusSchedule> busSchedules = null;
		
		busSchedules = bookingService.getBusSchedule();
		
		assertNotNull( busSchedules );
	}

	@Test(expected=BusBookingException.class)
	public void testBookABus() throws BusBookingException 
	{
		bookingService.bookABus(new BookingDetails("Test", 1, 9999));
	}

}
